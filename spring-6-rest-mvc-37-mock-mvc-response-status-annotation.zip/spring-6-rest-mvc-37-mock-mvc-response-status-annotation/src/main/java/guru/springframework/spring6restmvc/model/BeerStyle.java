package guru.springframework.spring6restmvc.model;

/**
 * Created by jt, Spring Framework Guru.
 */
public enum BeerStyle {
    LAGER, PILSNER, STOUT, GOSE, PORTER, ALE, WHEAT, IPA, PALE_ALE, SAISON
}
